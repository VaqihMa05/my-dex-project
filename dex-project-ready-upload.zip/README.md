
# 🦄 My DEX - Sepolia Testnet

A simple frontend DEX using vanilla JS + ethers.js. Tokens: ETH, USD, DAI, WETH, WSOL, WBNB.

## ✅ Features
- Real-time token price (CoinGecko)
- Token selection & dummy swap button
- Ready for Uniswap V2 router integration

## 🚀 Live on GitHub Pages
Just upload `/frontend` folder and activate GitHub Pages!

## 🛠️ Tech
- Ethers.js
- Vanilla JS
- CoinGecko API
